//
//  model.h
//  huoche
//
//  Created by kan xu on 11-1-8.
//  Copyright 2011 paduu. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "vo.h"
#import "savevo.h"

@interface model : NSObject {
	
	NSString *NetMsgErr;
	NSString *NetMsgche;
	NSString *NetMsgprice;
	vo *Modelvo;
	savevo *Modelsave;
	
}


+(model *)getInstance;
- (void)initModel;


@property (nonatomic, retain) vo *Modelvo;
@property (nonatomic, retain) savevo *Modelsave;

@property (nonatomic, retain) NSString *NetMsgErr;
@property (nonatomic, retain) NSString *NetMsgche;
@property (nonatomic, retain) NSString *NetMsgprice;


@end
