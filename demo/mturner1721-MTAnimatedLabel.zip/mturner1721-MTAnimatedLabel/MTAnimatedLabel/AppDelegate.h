//
//  AppDelegate.h
//  MTAnimatedLabel
//
//  Created by michael on 8/5/12.
//  Copyright (c) 2012 Michael Turner. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
