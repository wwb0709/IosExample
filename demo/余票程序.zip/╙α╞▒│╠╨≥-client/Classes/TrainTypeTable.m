//
//  TrainTypeTable.m
//  huoche
//
//  Created by kan xu on 11-1-7.
//  Copyright 2011 paduu. All rights reserved.
//  本程序中特别怀念 flex 里的数据绑定。数据的任何操作，最终都要手动对数据源进行修改，再存回model中。

#import "TrainTypeTable.h"
#import "model.h"


@implementation TrainTypeTable

@synthesize controller;

//上方开关，控制全选和全不选
- (void) SelAll:(id)sender{
	
	if (AllSel.on == YES ) {
		for (id key in [selectcell allKeys]){
			[selectcell setValue:@"1" forKey:key];		
		}
	}
	else {
		for (id key in [selectcell allKeys]){
			[selectcell setValue:@"0" forKey:key];
			
		}
	}
	
	[CheTable reloadData];	

}

//全选和全不选控制上方开关
- (void) CheckSel{

	BOOL tmpflag = YES;
	for (id key in [selectcell allKeys]){
		if ([[selectcell objectForKey:key] isEqualToString:@"0"]) {
			tmpflag = NO;
			break;
		}	
	}
	
	AllSel.on = tmpflag;	
	
}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	model *mydata = [model getInstance];
	self.controller = mydata.Modelvo.chetypes;
	selectcell = mydata.Modelvo.selchetypes;
	
	[self CheckSel];
	
}

//消失前将选择好的信息放入model
- (void) viewDidDisappear:(BOOL)animated{

	model *mydata = [model getInstance];
	mydata.Modelvo.selchetypes = selectcell;
	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}



#pragma mark -
#pragma mark Table View Delegate Methods

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	
	return [controller count];
	
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
	
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"test"];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                       reuseIdentifier: @"test"] autorelease];
    }
    // Configure the cell
	// NSUInteger row = [indexPath row];
    cell.textLabel.text = [controller objectAtIndex:indexPath.row];	
	//根据 selectCell 里面内容来判定勾选
	if ([[selectcell objectForKey:cell.textLabel.text] isEqualToString:@"1"]) {
		cell.accessoryType = UITableViewCellAccessoryCheckmark;
	}
	else {
		cell.accessoryType = UITableViewCellAccessoryNone;
	}
	return cell;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
		
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	
	NSLog(@"%@", cell.textLabel.text);
	//选择或取消选择
	if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
		cell.accessoryType = UITableViewCellAccessoryNone;
		//[selectcell removeObjectForKey:cell.textLabel.text];
		[selectcell setValue:@"0" forKey:cell.textLabel.text];
	}
	else {
		cell.accessoryType = UITableViewCellAccessoryCheckmark;
		[selectcell setValue:@"1" forKey:cell.textLabel.text];
		//NSLog(@"%@",selectcell);
	}
	
	//	for(int i = 0; i < [tableView numberOfRowsInSection:0]; i++){
	//		UITableViewCell *newCell = [tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
	//		newCell.accessoryType = UITableViewCellAccessoryCheckmark;
	//	}
	
	[self CheckSel];
	
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
	
}

/*
- (NSString *) tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
	
	if (section == 0) {
		return @"xxxxx";
	}
	else {
		return @"sss";
	}
	
}
*/


@end
