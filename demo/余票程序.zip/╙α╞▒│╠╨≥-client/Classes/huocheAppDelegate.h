//
//  huocheAppDelegate.h
//  huoche
//
//  Created by kan xu on 11-1-4.
//  Copyright 2011 paduu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface huocheAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

