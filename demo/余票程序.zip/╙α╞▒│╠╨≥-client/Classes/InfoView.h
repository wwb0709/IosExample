//
//  InfoView.h
//  huoche
//
//  Created by kan xu on 11-1-8.
//  Copyright 2011 paduu. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface InfoView : UIViewController {

	IBOutlet UIScrollView *Tinfo;
	IBOutlet UIView *Tinfoview;
	
	IBOutlet UILabel *lieLab;
	IBOutlet UILabel *traincodeLab;
	IBOutlet UILabel *startLab;
	IBOutlet UILabel *arriveLab;
	IBOutlet UILabel *starttimeLab;
	IBOutlet UILabel *arrivetimeLab;
	IBOutlet UILabel *listtimeLab;
	IBOutlet UILabel *yzuoLab;
	IBOutlet UILabel *rzuoLab;
	IBOutlet UILabel *ywoLab;
	IBOutlet UILabel *rwoLab;
	IBOutlet UILabel *tzuoLab;
	IBOutlet UILabel *zuo1Lab;
	IBOutlet UILabel *zuo2Lab;
	IBOutlet UILabel *baoLab;
	IBOutlet UILabel *nozuoLab;
	IBOutlet UILabel *levelLab;
	
	IBOutlet UILabel *yzuoPLab;
	IBOutlet UILabel *rzuoPLab;
	IBOutlet UILabel *ywoPLab;
	IBOutlet UILabel *rwoPLab;
	IBOutlet UILabel *tzuoPLab;
	IBOutlet UILabel *zuo1PLab;
	IBOutlet UILabel *zuo2PLab;
	IBOutlet UILabel *baoPLab;
	
	IBOutlet UIButton *map;
}


- (IBAction)StationMap:(id)sender;

@end
