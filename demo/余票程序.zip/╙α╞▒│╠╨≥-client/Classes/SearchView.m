//
//  SearchView.m
//  huoche
//
//  Created by kan xu on 11-1-7.
//  Copyright 2011 paduu. All rights reserved.
//

#import "SearchView.h"
#import "ResultView.h"
#import "TrainTypeTable.h"
#import "netControl.h"
#import "model.h"
#import "tooles.h"
#import "Kal.h"



@implementation SearchView

@synthesize controller;
@synthesize pickerdata;
@synthesize cityarr;

- (IBAction)Search:(id)sender {	
	
	if ([StartField.text isEqualToString:@""] || [ArriveField.text isEqualToString:@""]) {
		[tooles MsgBox:@"输入城市名"];	
		return;
	}

	if ([[self.controller lastObject] isEqualToString:@"车型:"]) {
		[tooles MsgBox:@"选择列车类型"];	
		return;
	}

	model *mydata = [model getInstance];
	mydata.Modelvo.start = StartField.text;
	mydata.Modelsave.start = mydata.Modelvo.start;	
	mydata.Modelvo.arrive = ArriveField.text;
	mydata.Modelsave.arrive = mydata.Modelvo.arrive;
	
	mydata.Modelsave.selchetypes = mydata.Modelvo.selchetypes;
	[mydata.Modelsave save];	
	[mynet GetCheList];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(SearchOK:) name:mydata.NetMsgche object:nil];
}

- (void) SearchOK:(id)sender{
	//navigationController 的标准调用形式，navigationController 栈内容和意义参考书，总之只有root 和 已经push的view 下才可以push view
	[self.navigationController popToRootViewControllerAnimated:NO];

	if (Result == nil) 
		Result = [[ResultView alloc] initWithNibName:@"ResultView" bundle:nil];
	[Result shouldAutorotateToInterfaceOrientation:UIInterfaceOrientationPortrait];	//下一界面必须为垂直界面。否则混乱
	[self.navigationController pushViewController:Result animated:YES];
	
	
}
//对 输入的城市名字 做判断，不应该有“市”存在，输入法联想很讨厌。这里说下再提交时应该再次过滤。
- (void) DoneEdit:(id)sender{

	[sender resignFirstResponder];
	//sender 就是谁发的事件
	UITextField *temp = (UITextField *)sender;
	temp.text = [temp.text stringByReplacingOccurrencesOfString:@"市" withString:@""];

	model *mydata = [model getInstance];	
	
	[mydata.Modelsave addcityarr:temp.text];
	[CityPicker reloadAllComponents];
	[CityPicker selectRow:0 inComponent:0 animated:YES];	
	

}

#pragma mark -
#pragma mark 按键

- (IBAction)Link:(id)sender{
	//打开网址标准方式
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.paduu.com/yupiao"]];

}

//星期五的日期放在事件的文本框里
- (void) FriDate:(id)sender{
	
	model *mydata = [model getInstance];
	
	NSDate *friday = [self ThisWeekFriday];
	SelDateField.text = [tooles Date2StrV:friday];
	mydata.Modelvo.chedate = friday;

}

//弹出actionSheets 里面是城市列表，设置出发城市
- (IBAction)SelStart:(id)sender{
	
	[StartField resignFirstResponder];
	
	model *mydata = [model getInstance];

	self.cityarr = mydata.Modelsave.cityarr;

	UIActionSheet *actionSheets = [[UIActionSheet alloc] initWithTitle:@"\n\n\n\n\n\n\n\n\n\n\n\n"
															 delegate:self cancelButtonTitle:nil 
											   destructiveButtonTitle:nil otherButtonTitles:@"设 置", nil];
	
	[actionSheets insertSubview:CityView atIndex:0];	
	[actionSheets showInView:self.view];
	pickerflag = @"start";
	
}

//弹出actionSheets 里面是城市列表，设置到达城市
- (IBAction)SelArriver:(id)sender{
	
	[ArriveField resignFirstResponder];
	
	model *mydata = [model getInstance];
	
	self.cityarr = mydata.Modelsave.cityarr;
	
	UIActionSheet *actionSheets = [[UIActionSheet alloc] initWithTitle:@"\n\n\n\n\n\n\n\n\n\n\n\n"
															  delegate:self cancelButtonTitle:nil 
												destructiveButtonTitle:nil otherButtonTitles:@"设 置", nil];
	
	[actionSheets insertSubview:CityView atIndex:0];	
	[actionSheets showInView:self.view];
	pickerflag = @"arrive";
	
}

//这里是 在 点击文本框时候 响应事件，注意头文件里要 实现 UITextFieldDelegate 并且 SelDateField.delegate = self 来指定delegate;
- (BOOL) textFieldShouldBeginEditing:(UITextField *)textField{
	
	model *mydata = [model getInstance];
	
	//很著名日期控件，这里已经汉化了，可以照如下方法使用
	kal = [[KalViewController alloc] init];
	kal.wantsFullScreenLayout = YES;

	[kal showAndSelectDate:mydata.Modelvo.chedate];
	
	//背景透明 ，否则好难看
	kalview.backgroundColor = [UIColor clearColor];
	CalView.backgroundColor = [UIColor clearColor];
	[kalview addSubview:kal.view];
	
	//actionSheet用法 看书 或是 文档
	UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
															 delegate:self cancelButtonTitle:nil 
											   destructiveButtonTitle:nil otherButtonTitles:@"设 置", nil];
	
	[actionSheet insertSubview:CalView atIndex:0];	
	[actionSheet showInView:self.view];
	
	pickerflag = @"date";
	return NO;
	
}

-(void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
	
	[actionSheet release];
	
	//弹出后的actionSheet 默认这里响应 这里通过 actionSheet不同来判断，或者直接按照这样，做个标志符 pickerflag 来告诉是谁要弹出的。
	model *mydata = [model getInstance];
	
	if ([pickerflag isEqualToString:@"start"]) {
		StartField.text = [cityarr objectAtIndex:[CityPicker selectedRowInComponent:0]];
		[mydata.Modelsave addcityarr:StartField.text];
		//city序列更新了，CityPicker内容刷新下，并且默认选中第二个
		[CityPicker reloadAllComponents];
		[CityPicker selectRow:1 inComponent:0 animated:YES];		
	}
	else if ([pickerflag isEqualToString:@"arrive"]) {
		ArriveField.text = [cityarr objectAtIndex:[CityPicker selectedRowInComponent:0]];
		[mydata.Modelsave addcityarr:ArriveField.text];		
		
		[CityPicker reloadAllComponents];
		[CityPicker selectRow:1 inComponent:0 animated:YES];	

	}
	else {
		SelDateField.text = [tooles Date2StrV:[kal selectedDate]];
		mydata.Modelvo.chedate = [kal selectedDate];
	}

	pickerflag = @"";
	//SelDateField.text = [pickerdata objectAtIndex:[DatePickerView selectedRowInComponent:0]];

}

//换换城市
- (void) TransCity:(id)sender{
	
	NSString *tempstr;
	
	tempstr = StartField.text;
	StartField.text = ArriveField.text;
	ArriveField.text = tempstr;

}


#pragma mark -
#pragma mark default

//从选择车列表界面回来的时候 已选择
- (void) viewWillAppear:(BOOL)animated{	

	
	model *mydata = [model getInstance];
	
	NSArray *array = [[NSArray alloc] initWithObjects:[mydata.Modelvo Selche2Str], nil];	
	self.controller = array;
	[array release];
	
	[TypeTable reloadData];	
	
}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];	
	
	self.view.autoresizesSubviews = NO;
	model *mydata = [model getInstance];
	
	self.cityarr = mydata.Modelsave.cityarr;	
	StartField.text = mydata.Modelsave.start;
	ArriveField.text = mydata.Modelsave.arrive;
	//SelDateField 响应 touch
	SelDateField.delegate = self;
	
	SelDateField.text = [tooles Date2StrV:mydata.Modelvo.chedate];
	
	mynet = [[netControl alloc] init];
	
	NSString *tempstr = self.navigationController.title;
	self.navigationController.title = @"网络登录中";
	//必须的，首先检查网络
	if ([mynet TestNet] == NO) {
		[tooles MsgBox:@"网络无法连接"];
	}
	else {
		self.navigationController.title = tempstr;
	}
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    //return (interfaceOrientation == UIInterfaceOrientationPortrait);
	//return YES;
}

- (void) willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
	
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
	
	[mynet release];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	[mynet release];
	[NextView release];
	[Result release];
}


#pragma mark -
#pragma mark Table View Delegate Methods
// 网络层直接参考 基础教程 这里只有一个cell
- (NSInteger)tableView:(UITableView *)tableView 
 numberOfRowsInSection:(NSInteger)section {
    return [self.controller count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *TypeCell= @"TypeCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: 
                             TypeCell];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                       reuseIdentifier: TypeCell] autorelease];
    }
    // Configure the cell
	//    NSUInteger row = [indexPath row];
    cell.textLabel.text = [controller objectAtIndex:indexPath.row];
	//    cell.imageView.image = controller.rowImage;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	//[cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}

// 点击后去选择按钮……这里做用table吃亏了，应该直接画个按钮在上面。
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	
	
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	[cell setSelectionStyle:UITableViewCellSelectionStyleNone];
	
	//[cell setSelectionStyle:UITableViewCellSelectionStyleBlue];	
	
    if (NextView == nil)
		NextView = [[TrainTypeTable alloc] initWithNibName:@"TrainTypeTable" bundle:nil];
	[self.navigationController pushViewController:NextView animated:YES];
	
}



#pragma mark -
#pragma mark Picker Data Source methods
//PickerView 参考基础教程
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [self.cityarr count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [self.cityarr objectAtIndex:row];
}


#pragma mark -
#pragma mark 工具代码段
// 最近的星期五，注意 西方星期和这里不同
- (NSDate *)ThisWeekFriday{
	int weekday = [[tooles DateInfo:[NSDate date]] weekday];
	int dayNum = weekday > 6 ? 13 - weekday : 6 - weekday ;	
	NSDate *calDate = [[NSDate date] addTimeInterval: dayNum * 60 * 60 * 24];
	return calDate;
	
}

@end
