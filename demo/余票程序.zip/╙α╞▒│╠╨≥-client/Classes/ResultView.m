//
//  ResultView.m
//  huoche
//
//  Created by kan xu on 11-1-8.
//  Copyright 2011 paduu. All rights reserved.
//  结果

#import "ResultView.h"
#import "model.h"
#import "netControl.h"
#import "RootCell.h"
#import "VCell.h"
#import "HCell.h"
#import "InfoView.h"
#import "tooles.h"

//数字排序
@implementation NSString (myCompare)

- (NSComparisonResult)myCompare:(NSString *)string
{
    return [self compare:string options:NSNumericSearch];
}

@end



@implementation ResultView

@synthesize controller;
@synthesize keys;
@synthesize NextView;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

//刷新下数据
- (void)freshdate{
	model *mymodel = [model getInstance];	
	NSString *uptime = mymodel.Modelvo.uptime;
	NSString *lieci = mymodel.Modelvo.lieci;
	NSString *tempstr = @"";
	tempstr = [[tempstr stringByAppendingString:uptime] stringByAppendingString:@"更新 共"];
	tempstr = [[tempstr stringByAppendingString:lieci] stringByAppendingString:@"列"];
	self.navigationItem.title = tempstr;	
	//self.keys = [[mymodel.Modelvo.Tchelist allKeys] sortedArrayUsingSelector:@selector(myCompare:)];
	//排序事件
	self.keys = mymodel.Modelvo.TimeIndex;
	self.controller = mymodel.Modelvo.Tchelist;
	[ListTable reloadData];
	

}

//刷新按钮 这里注释掉了
//- (void)refreshAction:(id)sender
//{
//	// the add button was clicked, handle it here
//	//	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"An Alert!" 
//	//												   delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//	//	[alert show];
//	//	[alert release];
//	
//	model *mymodel = [model getInstance];
//	
//	[mynet GetCheList];
//	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(netOK:) name:mymodel.NetMsgche object:nil];
//}
//
//- (void) netOK:(id)sender{	
//	[self freshdate];	
//}


#pragma mark -
#pragma mark default

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	//VResultView.autoresizesSubviews = NO;
	//HResultView.autoresizesSubviews = NO;
	mynet = [[netControl alloc] init];
	
//	model *mymodel = [model getInstance];	
//	[mymodel addObserver:self forKeyPath:@"Modelvo.chelist" options:0 context:nil];
//	这个就是kvc 类似as里的数据绑定机制，任何 Modelvo.chelist 值的改变都会触发默认的方法
//	
//	在导航条右上角加入一个按钮，这里不用了，刷新没有什麽意义
//	UIBarButtonItem *refreshButton = [[[UIBarButtonItem alloc] initWithTitle: @"刷新"
//														style:UIBarButtonItemStyleBordered
//														target:self
//														action:@selector(refreshAction:)] autorelease];
//	
//	self.navigationItem.rightBarButtonItem = refreshButton;
	
	
	
}

//[UIDevice currentDevice].orientation] 有六种状态，而interfaceOrientation只有两种。这里只是为了触发下。
- (void) viewWillAppear:(BOOL)animated{
	[self shouldAutorotateToInterfaceOrientation:[UIDevice currentDevice].orientation];
	[self freshdate];
}

//水平和垂直有 两个view 调用 中间用动画过渡
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    //return (interfaceOrientation == UIInterfaceOrientationPortrait);
	if ((interfaceOrientation == UIInterfaceOrientationLandscapeLeft) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight))
	{
		self.view.alpha = 0;
		CGContextRef context = UIGraphicsGetCurrentContext();
		[UIView beginAnimations:nil context:context];
		[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
		[UIView setAnimationDuration:1.0];
		self.view = HResultView;
		self.view.alpha = 1;
		[UIView commitAnimations];
		way = YES;
	}
	else if ((interfaceOrientation == UIInterfaceOrientationPortrait) || (interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown))
	{
		self.view.alpha = 0;
		CGContextRef context = UIGraphicsGetCurrentContext();
		[UIView beginAnimations:nil context:context];
		[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
		[UIView setAnimationDuration:1.0];
		self.view = VResultView;
		self.view.alpha = 1;
		[UIView commitAnimations];
		way = NO;
	}
	[ListTable reloadData];
	return YES;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	[mynet release];
	[NextView release];
}



//没用到，这就是kvc默认被触发的方法，这里没有用到，因为程序较为简单，几乎消息是一对一发送
//如果作为多个view或操作都会需要关联同一数据源，推荐这个方法,记得最后要remove
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
	
	model *mydata = [model getInstance];
	
	if (keyPath == @"Modelvo.chelist") {
		
	}
	
}


#pragma mark -
#pragma mark Table View Delegate methods
//标准的table使用方法，具体可以参见基础教程例子
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 85;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [keys count];
    
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	

	NSString *key = [keys objectAtIndex:section];
	id nameSection = [controller objectForKey:key];	
	if (nameSection == [NSNull null]) {
		return 0;
	}
    return [nameSection count];
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{	
	
	NSUInteger section = [indexPath section];
    NSUInteger row = [indexPath row];
    
    NSString *key = [keys objectAtIndex:section];
    id nameSection = [controller objectForKey:key];
	
	static NSString *CustomCellIdentifier = @"Cell";
	RootCell *cell;
	
	//cell = (VCell *)[tableView dequeueReusableCellWithIdentifier:CustomCellIdentifier];
	//if (UIDeviceOrientationIsLandscape([UIDevice currentDevice].orientation))
	if (way)
	{
		cell = (HCell *)[tableView dequeueReusableCellWithIdentifier:CustomCellIdentifier];
		if (cell == nil)  
		{		
			cell = [[[NSBundle mainBundle] loadNibNamed:@"HCell" owner:self options:nil] lastObject];

		}
	}
	else {		
		cell = (VCell *)[tableView dequeueReusableCellWithIdentifier:CustomCellIdentifier];
		if (cell == nil)
		{		
			cell = [[[NSBundle mainBundle] loadNibNamed:@"VCell" owner:self options:nil] lastObject];
		}
	}
	
//	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"list"];
//    if (cell == nil) {
//        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 
//                                       reuseIdentifier: @"list"] autorelease];
//    }
    // Configure the cell
	// NSUInteger row = [indexPath row];
	
	if (nameSection == [NSNull null]) {
		return cell;
	}
	
	cell.lieLab.text = [[nameSection objectAtIndex:row] objectForKey:@"lie"];
	cell.levelLab.text = [[nameSection objectAtIndex:row] objectForKey:@"level"];
	cell.startLab.text = [[nameSection objectAtIndex:row] objectForKey:@"start"];
	cell.starttimeLab.text = [[nameSection objectAtIndex:row] objectForKey:@"starttime"];
	cell.arriveLab.text = [[nameSection objectAtIndex:row] objectForKey:@"arrive"];
	cell.arrivetimeLab.text = [[nameSection objectAtIndex:row] objectForKey:@"arrivetime"];
	cell.listtimeLab.text = [[nameSection objectAtIndex:row] objectForKey:@"listtime"];
	cell.yzuoLab.text = [[nameSection objectAtIndex:row] objectForKey:@"yzuo"];
	cell.rzuoLab.text = [[nameSection objectAtIndex:row] objectForKey:@"rzuo"];
	cell.ywoLab.text = [[nameSection objectAtIndex:row] objectForKey:@"ywo"];
	cell.rwoLab.text = [[nameSection objectAtIndex:row] objectForKey:@"rwo"];
	cell.tzuoLab.text = [[nameSection objectAtIndex:row] objectForKey:@"tzuo"];
	cell.zuo1Lab.text = [[nameSection objectAtIndex:row] objectForKey:@"1zuo"];
	cell.zuo2Lab.text = [[nameSection objectAtIndex:row] objectForKey:@"2zuo"];
	cell.baoLab.text = [[nameSection objectAtIndex:row] objectForKey:@"bao"];
	cell.nozuoLab.text = [[nameSection objectAtIndex:row] objectForKey:@"nozuo"];
	cell.traincodeLab.text = [[nameSection objectAtIndex:row] objectForKey:@"traincode"];

//	cell.textLabel.text = [[nameSection objectAtIndex:row] objectForKey:@"lie"];
//	cell.detailTextLabel.text = [[nameSection objectAtIndex:row] objectForKey:@"starttime"];
	
	//NSLog(cell.textLabel.text);
	
    //cell.textLabel.text = [[controller objectAtIndex:indexPath.row] objectForKey:@"lie"];
	//cell.detailTextLabel.text = [[controller objectAtIndex:indexPath.row] objectForKey:@"starttime"];
	return cell;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	
	//RootCell *cell = (RootCell *)[tableView cellForRowAtIndexPath:indexPath];
	
	NSUInteger section = [indexPath section];
    NSUInteger row = [indexPath row];
	
	NSString *key = [keys objectAtIndex:section];
    id nameSection = [controller objectForKey:key];	

	model *mydata = [model getInstance];
	mydata.Modelvo.traincode = [[nameSection objectAtIndex:row] objectForKey:@"traincode"];
	mydata.Modelvo.selche = [nameSection objectAtIndex:row];	
	[self GetPrice];
}


- (NSArray *) sectionIndexTitlesForTableView:(UITableView *)tableView{

	model *mydata = [model getInstance];
	
	return  mydata.Modelvo.TimeIndex;

}

- (void)GetPrice{
	model *mydata = [model getInstance];
	[mynet GetChePrice];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(PriceOK:) name:mydata.NetMsgprice object:nil];
	//消息机制 [NSNotificationCenter defaultCenter] 各个模块间可以通过这个通讯，但是效率较低，不适合频繁使用
}

- (void)PriceOK:(id)sender{
	
	[self.navigationController popToViewController:self animated:NO];
	if (NextView == nil)
		NextView = [[InfoView alloc] initWithNibName:@"InfoView" bundle:nil];
	[self.navigationController pushViewController:NextView animated:YES];
	//以上为标准调用方式 1、设置当前页面为根(或返回)页面 2、塞入新页面
	
	//NSLog(@"%@",self.navigationController);
	//[NextView release];
	//[tableView deselectRowAtIndexPath:indexPath animated:YES];
}


@end
