//
//  SearchView.h
//  huoche
//
//  Created by kan xu on 11-1-7.
//  Copyright 2011 paduu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Kal.h"

@class netControl;


@interface SearchView : UIViewController  <	UIPickerViewDelegate,UIPickerViewDataSource,
											UIActionSheetDelegate, UITextFieldDelegate,
											UITableViewDataSource, UITableViewDelegate
											>
{
	
	NSArray *controller;
	netControl *mynet;
	
	
	NSArray *cityarr;		//常用城市表
	
	NSString *pickerflag;	//三种状态：start arrive date
	
	IBOutlet UIViewController *Result;
	IBOutlet UIViewController *NextView;
	IBOutlet UITableView *TypeTable;
	IBOutlet UITextField *SelDateField;
	IBOutlet UITextField *StartField;
	IBOutlet UITextField *ArriveField;
	
	
	IBOutlet UIPickerView *CityPicker;
	IBOutlet KalView *kalview;
	IBOutlet KalViewController *kal;
//	IBOutlet UIPickerView *StartPicker;
//	IBOutlet UIPickerView *ArrivePicker;
	
	IBOutlet UIView *TestView;
	IBOutlet UIView *CityView;
	IBOutlet UIView *CalView;
//	IBOutlet UIView *StartView;
//	IBOutlet UIView *ArriverView;
}

@property (nonatomic, retain) NSArray *controller;
@property (nonatomic, retain) NSArray *pickerdata;
@property (nonatomic, retain) NSArray *cityarr;


- (IBAction)Search:(id)sender;
- (IBAction)DoneEdit:(id)sender;

- (IBAction)FriDate:(id)sender;
- (IBAction)SelDate:(id)sender;
- (IBAction)SelStart:(id)sender;
- (IBAction)SelArriver:(id)sender;

- (IBAction)TransCity:(id)sender;
- (IBAction)Link:(id)sender;
@end
