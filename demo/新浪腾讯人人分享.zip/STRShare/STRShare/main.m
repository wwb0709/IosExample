//
//  main.m
//  STRShare
//
//  Created by chen xin on 12-9-18.
//  Copyright (c) 2012年 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "KYAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([KYAppDelegate class]));
    }
}
