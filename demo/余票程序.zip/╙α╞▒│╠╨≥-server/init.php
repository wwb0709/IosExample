﻿<?php
/**
 * 火车信息查询 [From 12306.cn]
 *
 * @调试代码，直接运行获得内容
 * @version $ID 2010-04-12 $
 */
header("Pragma:no-cache");

// Include
require_once 'snoopy.class.php';

// 使用Snoopy
$snoopy = new Snoopy;

$submit_url = "http://dynamic.12306.cn/TrainQuery/iframeLeftTicketByStation.jsp";

$snoopy->host = "dynamic.12306.cn";
//$snoopy->expandlinks = true;

$snoopy->rawheaders["Pragma"] = "no-cache"; //cache 的http头信息

//$snoopy->rawheaders["Origin"] =  "http://dynamic.12306.cn"; //cache 的http头信息
$snoopy->rawheaders["Accept-Charset"] = "UTF-8,*;q=0.5";
//$snoopy->rawheaders["Accept-Encoding"] = "gzip,deflate,sdch";
//$snoopy->rawheaders["Accept-Language"] = "zh-CN,zh;q=0.8";
//$snoopy->rawheaders["Content-Type"] = "application/x-www-form-urlencoded";
//$snoopy->rawheaders["Pragma"] = "no-cache";
//$snoopy->maxredirs = 0;

//$snoopy->proxy_host = "http://dynamic.12306.cn";


$snoopy->referer = $submit_url;

//$snoopy->cookies["SessionID"] = "";
//$snoopy->agent = "(Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.11 (KHTML, like Gecko) Chrome/9.0.570.1 Safari/534.11)";
//$snoopy->accept = "application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5";
$submit_vars["ictM"] = "1638";
$submit_vars["fdl"] = "fdl";
$submit_vars["fdl0"] = "fdl0";
$submit_vars["lx"] = "00";
$submit_vars["nyear3"] = "2011";
$submit_vars["nyear3_new_value"] = "true";
$submit_vars["nmonth3"] = "3";
$submit_vars["nmonth3_new_value"] = "true";
$submit_vars["nday3"] = "22";
$submit_vars["nday3_new_value"] = "false";
$submit_vars["startStation_ticketLeft"] = "5408801a05070adb";
$submit_vars["startStation_ticketLeft_new_value"] = "false";
$submit_vars["arriveStation_ticketLeft"] = "6b666cf6016ea792";
$submit_vars["arriveStation_ticketLeft_new_value"] = "false";
$submit_vars["trainCode"] = "";
$submit_vars["trainCode_new_value"] = "true";
$submit_vars["rFlag"] = "1";
$submit_vars["tFlagDC"] = "DC";


$snoopy->submit($submit_url,$submit_vars);
//$snoopy->fetch($submit_url);

//print_r($snoopy);
$backjs = $snoopy->results;
print_r($backjs);


?>