//
//  KYAppDelegate.h
//  STRShare
//
//  Created by chen xin on 12-9-18.
//  Copyright (c) 2012年 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>

@class KYViewController;

@interface KYAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) KYViewController *viewController;
@property (strong, nonatomic) UINavigationController *navCtrl;

@end
