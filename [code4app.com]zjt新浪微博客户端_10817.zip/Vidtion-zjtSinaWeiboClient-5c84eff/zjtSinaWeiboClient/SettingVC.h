//
//  SettingVC.h
//  zjtSinaWeiboClient
//
//  Created by Jianting Zhu on 12-4-25.
//  Copyright (c) 2012年 ZUST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingVC : UITableViewController<UIAlertViewDelegate>

@end
