//
//  RootCell.h
//  huoche
//
//  Created by kan xu on 11-1-7.
//  Copyright 2011 paduu. All rights reserved.
//  本段直接参考 ip 3 开发基础教程 table一节 RootCell 派生出 垂直cell 和 水平 cell

#import <UIKit/UIKit.h>


@interface RootCell : UITableViewCell {
	
	
	NSString *titleStr;
	
	IBOutlet UILabel *lieLab;
	IBOutlet UILabel *traincodeLab;
	IBOutlet UILabel *startLab;
	IBOutlet UILabel *arriveLab;
	IBOutlet UILabel *starttimeLab;
	IBOutlet UILabel *arrivetimeLab;
	IBOutlet UILabel *listtimeLab;
	IBOutlet UILabel *yzuoLab;
	IBOutlet UILabel *rzuoLab;
	IBOutlet UILabel *ywoLab;
	IBOutlet UILabel *rwoLab;
	IBOutlet UILabel *tzuoLab;
	IBOutlet UILabel *zuo1Lab;
	IBOutlet UILabel *zuo2Lab;
	IBOutlet UILabel *baoLab;
	IBOutlet UILabel *nozuoLab;
	IBOutlet UILabel *levelLab;
}

@property (nonatomic, retain) IBOutlet UILabel *lieLab;
@property (nonatomic, retain) IBOutlet UILabel *traincodeLab;
@property (nonatomic, retain) IBOutlet UILabel *startLab;
@property (nonatomic, retain) IBOutlet UILabel *arriveLab;
@property (nonatomic, retain) IBOutlet UILabel *starttimeLab;
@property (nonatomic, retain) IBOutlet UILabel *arrivetimeLab;
@property (nonatomic, retain) IBOutlet UILabel *listtimeLab;
@property (nonatomic, retain) IBOutlet UILabel *yzuoLab;
@property (nonatomic, retain) IBOutlet UILabel *rzuoLab;
@property (nonatomic, retain) IBOutlet UILabel *ywoLab;
@property (nonatomic, retain) IBOutlet UILabel *rwoLab;
@property (nonatomic, retain) IBOutlet UILabel *tzuoLab;
@property (nonatomic, retain) IBOutlet UILabel *zuo1Lab;
@property (nonatomic, retain) IBOutlet UILabel *zuo2Lab;
@property (nonatomic, retain) IBOutlet UILabel *baoLab;
@property (nonatomic, retain) IBOutlet UILabel *nozuoLab;
@property (nonatomic, retain) IBOutlet UILabel *levelLab;

@end
