//
//  HCell.h
//  huoche
//
//  Created by kan xu on 11-1-7.
//  Copyright 2011 paduu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RootCell.h"


@interface HCell : RootCell {

}

@end
