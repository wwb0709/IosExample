<?php
/**
 * 火车信息查询 [From 12306.cn]--外部调用API
 *
 * @获得票价,建议建库获得，也可这样直接从网上获得
 * @version $ID 2010-04-12 $
 */
header("Pragma:no-cache");

// Include
require_once 'JsonMsg.class.php';
require_once 'snoopy.class.php';
require_once 'exejs.php';


if (!array_key_exists( 'date',$_REQUEST)){
	exit();
}

$form["start"] = $_REQUEST["start"];
//$form["start"] = iconv("UTF-8", "gbk", $form["start"]);
$form["arrive"] = $_REQUEST["arrive"];
//$form["arrive"] = iconv("UTF-8", "gbk", $form["arrive"]);
$form["date"] = $_REQUEST["date"];
$form["year"] = substr($form["date"],0,4);
$form["month"] = substr($form["date"],4,2);
$form["day"] = substr($form["date"],6,2);
$form["traincode"] = $_REQUEST["traincode"];


$mem = new Memcache;
$mem->connect("localhost", 11211);

// 使用Snoopy
$snoopy = new Snoopy;
$jsonmsg = new JsonMsg;

$submit_url = "http://dynamic.12306.cn/TrainQuery/iframeTicketPriceByStation.jsp";

$snoopy->host = "dynamic.12306.cn";
//$snoopy->expandlinks = true;

$snoopy->rawheaders["Pragma"] = "no-cache"; //cache 的http头信息

//$snoopy->rawheaders["Origin"] =  "http://dynamic.12306.cn"; //cache 的http头信息
$snoopy->rawheaders["Accept-Charset"] = "UTF-8,*;q=0.5";


$snoopy->referer = $submit_url;

$submit_vars["condition"] = "";
$submit_vars["nyear2"] =$form["year"];
$submit_vars["nyear2_new_value"] = "true";
$submit_vars["nmonth2"] = $form["month"];
$submit_vars["nmonth2_new_value"] = "true";
$submit_vars["nday2"] = $form["day"];
$submit_vars["nday2_new_value"] = "false";
$submit_vars["startStation_ticketPrice"] = $form["start"];
//$submit_vars["startStation_ticketPrice"] = "武汉";
$submit_vars["startStation_ticketPrice_new_value"] = "false";
$submit_vars["arriveStation_ticketPrice"] = $form["arrive"];
//$submit_vars["arriveStation_ticketPrice"] = "上海";
$submit_vars["arriveStation_ticketPrice_new_value"] = "false";
$submit_vars["trainCode"] =  $form["traincode"];
//$submit_vars["trainCode"] =  "D3083";
$submit_vars["name_ckball"] = "value_ckball";
$submit_vars["trainCode_new_value"] = "true";
$submit_vars["rFlag"] = "1";

$submit_vars["tFlagDC"] = "DC";
$submit_vars["tFlagZ"] = "Z";
$submit_vars["tFlagT"] = "T";
$submit_vars["tFlagK"] = "K";
$submit_vars["tFlagPK"] = "PK";
$submit_vars["tFlagPKE"] = "PKE";
$submit_vars["tFlagLK"] = "LK";

Getxx();
//print_r($submit_vars);
//echo preg_replace("#\\\u([0-9a-f]+)#ie", "iconv('UCS-2', 'UTF-8', pack('H4', '\\1'))", Getxx());


function Getxx() {
	global $submit_vars,$snoopy,$jsonmsg,$submit_url;

	//$snoopy->submit($submit_url,$submit_vars);
	//$snoopy->fetch($submit_url);

	//print_r($submit_vars);
	if (!$snoopy->submit($submit_url,$submit_vars)){
		$jsonmsg->error = "超时错误";
		$jsonmsg->jsonout;
		exit;
	};

	$backjs = $snoopy->results;

	$chearr = mystr($backjs,'parent.mygrid.addRow(','<!--');
	$chearr  = str_replace(" ","",$chearr);
	$chearr  = str_replace('"',"",$chearr);
	$chearr = str_ireplace("parent.mygrid.addRow(","  ",$chearr);
	$chearr = explode(');',$chearr);
	unset($chearr[count($chearr)-1]);

	$i=0;

	if ($chearr == null){
		$jsonmsg->error = "列车票价信息暂无";
		$jsonmsg->jsonout();
		exit;
	}


	foreach ($chearr as $v) {
	   $chexx[$i] = explode(',',$v);
	   $i++;
	}

	foreach ($chexx as $v) {
	   $backval["yzuo"] = $v[5];
	   $backval["rzuo"] = $v[6];
	   $backval["ywo"] = $v[7];
	   $backval["rwo"] = $v[8];
	   $backval["1zuo"] = $v[9];
	   $backval["2zuo"] = $v[10];
	   $backval["tzuo"] = $v[11];
	   $backval["bao"] = $v[12];
	}

	//echo json_encode($backval);
	$jsonmsg->result = $backval;
	if ($jsonmsg->result == null){
		$jsonmsg->error = "列车票价信息暂无";
	}
	$jsonmsg->jsonout();
}

function mystr($string,$search1,$search2) {

	$tempstr= ltrim(strstr($string,$search1),$search1);
	$i= stripos($tempstr,$search2);
	return substr($tempstr,0,$i);
}

function leftstr($search1,$string) {

	$tempstr=explode($search1,$string);
	return $tempstr[0];
}

function charCodeAt($str, $i){
	return ord(substr($str, $i, 1));
}
?>