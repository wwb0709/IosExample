<?php

	phpinfo();
?>