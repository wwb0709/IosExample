//
//  InfoView.m
//  huoche
//
//  Created by kan xu on 11-1-8.
//  Copyright 2011 paduu. All rights reserved.
//  详细信息。包含票价信息

#import "InfoView.h"
#import "tooles.h"
#import "model.h"


@implementation InfoView


-(void) StationMap:(id)sender{
	
	
	model *mydata = [model getInstance];

	NSString *addr=[NSString stringWithFormat:@"中国,%@,售票处",mydata.Modelvo.start];

	[tooles OpenUrl:[NSString stringWithFormat:@"http://maps.google.com/maps?q=%@",
					 [addr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];

}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	Tinfo.contentSize = CGSizeMake(0, 230);
	[Tinfo addSubview:Tinfoview];
	self.view.autoresizesSubviews = NO;
}

- (void) viewWillAppear:(BOOL)animated{

	Tinfo.contentOffset = CGPointMake(0, 0);	
	model *mydata = [model getInstance];
	NSDictionary *cheinfo = mydata.Modelvo.selche;
	NSDictionary *chePinfo = mydata.Modelvo.pricelist;
	
	lieLab.text = [cheinfo objectForKey:@"lie"];
	levelLab.text = [cheinfo objectForKey:@"level"];
	startLab.text = [cheinfo objectForKey:@"start"];
	starttimeLab.text = [cheinfo objectForKey:@"starttime"];
	arriveLab.text = [cheinfo objectForKey:@"arrive"];
	arrivetimeLab.text = [cheinfo objectForKey:@"arrivetime"];
	listtimeLab.text = [cheinfo objectForKey:@"listtime"];
	yzuoLab.text = [cheinfo objectForKey:@"yzuo"];
	rzuoLab.text = [cheinfo objectForKey:@"rzuo"];
	ywoLab.text = [cheinfo objectForKey:@"ywo"];
	rwoLab.text = [cheinfo objectForKey:@"rwo"];
	tzuoLab.text = [cheinfo objectForKey:@"tzuo"];
	zuo1Lab.text = [cheinfo objectForKey:@"1zuo"];
	zuo2Lab.text = [cheinfo objectForKey:@"2zuo"];
	baoLab.text = [cheinfo objectForKey:@"bao"];
	nozuoLab.text = [cheinfo objectForKey:@"nozuo"];
	
	yzuoPLab.text = [chePinfo objectForKey:@"yzuo"];
	rzuoPLab.text = [chePinfo objectForKey:@"rzuo"];
	ywoPLab.text = [chePinfo objectForKey:@"ywo"];
	rwoPLab.text = [chePinfo objectForKey:@"rwo"];
	tzuoPLab.text = [chePinfo objectForKey:@"tzuo"];
	zuo1PLab.text = [chePinfo objectForKey:@"1zuo"];
	zuo2PLab.text = [chePinfo objectForKey:@"2zuo"];
	baoPLab.text = [chePinfo objectForKey:@"bao"];
	

	NSString *maptitle = [mydata.Modelvo.start stringByAppendingFormat:@"售票点地图"];
	[map setTitle:maptitle forState:UIControlStateNormal];

}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
	//return NO;
    //return (interfaceOrientation == UIInterfaceOrientationPortrait);
//	[[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationPortrait];
//    self.navigationController.view.transform = CGAffineTransformIdentity;
//    //self.navigationController.view.transform = CGAffineTransformMakeRotation(M_PI*(90)/180.0);
//    self.navigationController.view.bounds = CGRectMake(0, 0, 320, 480);
}






- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
