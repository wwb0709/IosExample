//
//  netControl.m
//  huoche
//
//  Created by kan xu on 11-1-9.
//  Copyright 2011 paduu. All rights reserved.
//  网络处理部分
//  ASIHTTPRequest 使用 具体可见官网 http://allseeing-i.com/ASIHTTPRequest/
//  json 使用 touchjson 具体可见 https://github.com/TouchCode/TouchJSON

#import "netControl.h"
#import "ASIHttpHeaders.h"
#import "CJSONDeserializer.h"
#import "model.h"
#import "tooles.h"
#import "Reachability.h"

@implementation netControl


-(void) GetCheList{
	
	model *mydata = [model getInstance];
	
	NSString *urlstr = @"http://127.0.0.1/app/index.php";	//注意换成自己服务器地址 model里有appaddr 最后忘了
	NSURL *myurl = [NSURL URLWithString:urlstr];
	ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:myurl];
	
	[request setPostValue:mydata.Modelvo.chedatestr forKey:@"date"];	
	[request setPostValue:mydata.Modelvo.start forKey:@"start"];
	[request setPostValue:mydata.Modelvo.arrive forKey:@"arrive"];
	[request setPostValue:mydata.Modelvo.cheflag forKey:@"flag"];
	
	[request setDelegate:self];
	[request setDidFinishSelector:@selector(CheList:)];
	[request setDidFailSelector:@selector(GetErr:)];
	[request startAsynchronous];
	
	[tooles showHUD:@"获取余票信息，请耐心等待..."];
	
}

- (void)CheList:(ASIHTTPRequest *)request{	
	
	[tooles removeHUD];
	
	model *mymodel = [model getInstance];
	
	NSData *response = [request responseData];	
//	NSString *mytext = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
//	NSLog(@"CheListOK");
	
	NSDictionary *dictionary = [[CJSONDeserializer deserializer] deserializeAsDictionary:response error:nil];
//	if ([dictionary objectForKey:@"uptime"] == NULL) {
//		[tooles MsgBox:@"服务器返回错误"];		
//	}
//	json返回 {"error":"无余票信息","result":null} 为错误信息
	if ([dictionary objectForKey:@"error"] != [NSNull null]) {
		[tooles MsgBox:[dictionary objectForKey:@"error"]];
		return;
	}
	
	NSDictionary *result = [dictionary objectForKey:@"result"];
	
	mymodel.Modelvo.uptime = [result objectForKey:@"uptime"];
	mymodel.Modelvo.lieci = [result objectForKey:@"lieci"];
	mymodel.Modelvo.chelist = [result objectForKey:@"chelist"];
	//NSLog(@"%@",[result objectForKey:@"chelist"]);
	//mytext = [[[result objectForKey:@"chelist"] objectAtIndex:0] objectForKey:@"lie"];
	//NSLog(@"%@",mymodel.Modelvo.chelist);
	[mymodel.Modelvo chelist2T];
	[[NSNotificationCenter defaultCenter] postNotificationName:mymodel.NetMsgche object:nil];
}


- (void)GetChePrice{
	
	model *mydata = [model getInstance];	

	NSString *urlstr = @"http://127.0.0.1/app/index.php";
	NSURL *myurl = [NSURL URLWithString:urlstr];
	ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:myurl];
	
	[request setPostValue:mydata.Modelvo.chedatestr forKey:@"date"];	
	[request setPostValue:mydata.Modelvo.start forKey:@"start"];
	[request setPostValue:mydata.Modelvo.arrive forKey:@"arrive"];
	[request setPostValue:mydata.Modelvo.traincode forKey:@"traincode"];
	
	[request setDelegate:self];
	[request setDidFinishSelector:@selector(PriceList:)];
	[request setDidFailSelector:@selector(GetErr:)];
	[request startAsynchronous];
	
	[tooles showHUD:@"获取详细信息"];

}


- (void)PriceList:(ASIHTTPRequest *)request{	
	
	[tooles removeHUD];
	
	model *mymodel = [model getInstance];
	
	NSData *response = [request responseData];	
	//	NSString *mytext = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
	//	NSLog(@"CheListOK");
	
	NSDictionary *dictionary = [[CJSONDeserializer deserializer] deserializeAsDictionary:response error:nil];
	//	if ([dictionary objectForKey:@"uptime"] == NULL) {
	//		[tooles MsgBox:@"服务器返回错误"];		
	//	}
	
	if ([dictionary objectForKey:@"error"] != [NSNull null]) {
		[tooles MsgBox:[dictionary objectForKey:@"error"]];
		return;
	}
	
	NSDictionary *result = [dictionary objectForKey:@"result"];
	
	mymodel.Modelvo.pricelist = result;
	
	[[NSNotificationCenter defaultCenter] postNotificationName:mymodel.NetMsgprice object:nil];
}




//网络错误处理
- (void)GetErr:(ASIHTTPRequest *)request{
	
	[tooles removeHUD];
	
	NSError *error = [request error];
	
	[tooles MsgBox:@"连接超时，等会试试"];
}


//测试代码
- (BOOL)TestNet{
	Reachability *r = [Reachability reachabilityWithHostName:@"127.0.0.1"];
	switch ([r currentReachabilityStatus]) {
		case NotReachable:
			// 没有网络连接
			return NO;
			break;
		case ReachableViaWWAN:
			// 使用3G网络
			return YES;
			break;
		case ReachableViaWiFi:
			// 使用WiFi网络
			return YES;
			break;
    }
	return YES;
}

@end
