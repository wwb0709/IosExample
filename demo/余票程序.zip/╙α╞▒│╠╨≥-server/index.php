<?php
/**
 * 火车信息查询 [From 12306.cn]
 *
 * @获得余票
 * @version $ID 2011-04-12 $
 */
header("Pragma:no-cache");

// Include
require_once 'JsonMsg.class.php';	//json序列化
require_once 'snoopy.class.php';	//snoopy 采集类
require_once 'exejs.php';	//余票站点js代码

if (!array_key_exists( 'date',$_REQUEST)){
	exit();
}


$form["start"] = $_REQUEST["start"];
$form["start"] = iconv("UTF-8", "gbk", $form["start"]);	//js代码中需要
$form["arrive"] = $_REQUEST["arrive"];
$form["arrive"] = iconv("UTF-8", "gbk", $form["arrive"]);
$form["date"] = $_REQUEST["date"];
$form["year"] = substr($form["date"],0,4);
$form["month"] = substr($form["date"],4,2);
$form["day"] = substr($form["date"],6,2);
$form["flag"] = $_REQUEST["flag"];

//Memcache 中存取当前放抓取标识符
//12306.cn 有放抓取限制标志
$mem = new Memcache;
$mem->connect("localhost", 11211);

// 使用Snoopy
$snoopy = new Snoopy;
$jsonmsg = new JsonMsg;

$submit_url = "http://dynamic.12306.cn/TrainQuery/iframeLeftTicketByStation.jsp";
$submit_js = "http://dynamic.12306.cn/TrainQuery/createCombo/yp.js";

$snoopy->host = "dynamic.12306.cn";
//$snoopy->expandlinks = true;

$snoopy->rawheaders["Pragma"] = "no-cache"; //cache 的http头信息

//$snoopy->rawheaders["Origin"] =  "http://dynamic.12306.cn"; //cache 的http头信息
$snoopy->rawheaders["Accept-Charset"] = "UTF-8,*;q=0.5";



$snoopy->referer = $submit_url;

$submit_vars["trainquery_lsX"] = "1234";	//防抓取标识符
$submit_vars["fdl"] = "fdl";	//防抓取标识符
$submit_vars["fdl0"] = "fdl0";	//防抓取标识符
$submit_vars["lx"] = "00";
$submit_vars["nyear3"] =$form["year"];	 //年
$submit_vars["nyear3_new_value"] = "true";
$submit_vars["nmonth3"] = $form["month"];	 //月
$submit_vars["nmonth3_new_value"] = "true";
$submit_vars["nday3"] = $form["day"];	//日
$submit_vars["nday3_new_value"] = "false";
$submit_vars["startStation_ticketLeft"] =  Getcitynum($form["start"]);	//起始站编码
$submit_vars["startStation_ticketLeft_new_value"] = "false";
$submit_vars["arriveStation_ticketLeft"] = Getcitynum($form["arrive"]);	//抵达站编码
$submit_vars["arriveStation_ticketLeft_new_value"] = "false";
$submit_vars["trainCode"] = "";
$submit_vars["trainCode_new_value"] = "true";
$submit_vars["rFlag"] = "1";

if (substr($form["flag"],0,1) == "1") $submit_vars["tFlagDC"] = "DC";	//动车，拼音首字母
if (substr($form["flag"],1,1) == "1") $submit_vars["tFlagZ"] = "Z";
if (substr($form["flag"],2,1) == "1") $submit_vars["tFlagT"] = "T";
if (substr($form["flag"],3,1) == "1") $submit_vars["tFlagK"] = "K";
if (substr($form["flag"],4,1) == "1") $submit_vars["tFlagPK"] = "PK";
if (substr($form["flag"],5,1) == "1") $submit_vars["tFlagPKE"] = "PKE";
if (substr($form["flag"],6,1) == "1") $submit_vars["tFlagLK"] = "LK";

//取得放抓取内容信息
$backval = $mem->get('initxx');
if ($backval == null || $backval["chebh"] == null){
	Getfdl();
	$backval = $mem->get('initxx');
}

$submit_vars[$backval["chebh"]] = $backval["checode"];
//print_r($submit_vars);
$jsonmsg->result = Getxx();

if ($jsonmsg->result == null){
	$jsonmsg->error = "无余票信息";
}
$jsonmsg->jsonout();

//js加密代码，直接在yp.js 中取得。可以直接复制使用。windows下用 COM控件， linux系统下用 php-js-ext 具体见//http://aurore.net/projects/php-js/
function Getcitynum($cityname) {
	global $submit_vars,$snoopy,$submit_js,$mem,$scriptstr;

	$strmm = 'liusheng';
	$strmm = iconv("UTF-8", "gbk", $strmm);
	$oScript = new COM("MSScriptControl.ScriptControl");
	$oScript->Language = "JavaScript";
	$oScript->AllowUI = false;
	$oScript->AddCode($scriptstr);
	return $oScript->Run("trans", $cityname,$strmm);
}

//以下测试代码，不用管
function Getfjs() {
	global $submit_vars,$snoopy,$submit_js,$mem;

	$strmm = '\x6c\x69\x75\x73\x68\x65\x6e\x67';

	$snoopy->fetch($submit_js);
	$backjs = $snoopy->results;
	return;
}

//获取防抓取标识符，存入memcache ，3小时失效
function Getfdl() {
	global $submit_vars,$snoopy,$submit_url,$mem;

	$snoopy->submit($submit_url,$submit_vars);
	$backjs = $snoopy->results;
	$backval["uptime"] =  mystr($backjs,'本次信息更新时间为','。"');
	$backjs = substr($backjs,20);
	$backval["chebh"] = mystr($backjs,'parent.document.getElementById("','").value');
	$backval["checode"] = mystr($backjs,').value="','"');
	$mem->set('initxx', $backval, 0, 7200);
	return;
}

//获得信息
function Getxx() {
	global $submit_vars,$snoopy,$submit_url;

	if (!$snoopy->submit($submit_url,$submit_vars)){
		$jsonmsg->error = "超时错误";
		$jsonmsg->jsonout();
		exit;
	};

	$backjs = $snoopy->results;

	$backval["uptime"] =  mystr($backjs,'本次信息更新时间为','。');
	$backval["lieci"] =  mystr($backjs,'列车全部余票信息<strong>','</strong>条');
	$chearr = mystr($backjs,'parent.mygrid.addRow(','</script>');
	$chearr  = str_replace(" ","",$chearr);
	$chearr  = str_replace('"',"",$chearr);
	$chearr = str_ireplace("parent.mygrid.addRow(","  ",$chearr);
	$chearr = explode(');',$chearr);
	unset($chearr[count($chearr)-1]);

	$i=0;

	if ($chearr == null)return;

	foreach ($chearr as $v) {
	   $chexx[$i] = explode(',',$v);
	   $i++;
	}



	$i=0;
	foreach ($chexx as $v) {
	   $backval["chelist"][$i]["lie"] = leftstr('^',$v[2]);
	   $backval["chelist"][$i]["traincode"] = leftstr('(',$backval["chelist"][$i]["lie"]);
	   $backval["chelist"][$i]["start"] = leftstr('^',$v[3]);
	   $backval["chelist"][$i]["arrive"] = leftstr('^',$v[4]);
	   $backval["chelist"][$i]["starttime"] = $v[5];
	   $backval["chelist"][$i]["startt"] =  GetHour($backval["chelist"][$i]["starttime"]);
	   $backval["chelist"][$i]["arrivetime"] = $v[6];
	   $backval["chelist"][$i]["listtime"] = $v[7];
	   $backval["chelist"][$i]["yzuo"] = $v[8];
	   $backval["chelist"][$i]["rzuo"] = $v[9];
	   $backval["chelist"][$i]["ywo"] = $v[10];
	   $backval["chelist"][$i]["rwo"] = $v[11];
	   $backval["chelist"][$i]["tzuo"] = $v[12];
	   $backval["chelist"][$i]["1zuo"] = $v[13];
	   $backval["chelist"][$i]["2zuo"] = $v[14];
	   $backval["chelist"][$i]["bao"] = $v[15];
	   $backval["chelist"][$i]["nozuo"] = $v[16];
	   $backval["chelist"][$i]["level"] = $v[17];
	   $i++;
	}
	//print_r($backval);
	//echo json_encode($backval);
	return $backval;
}

//工具代码
function GetHour($string) {

	$hour = leftstr(':',$string);

	if (substr($hour,0,1) == "0"){
		$hour = substr($hour,1);
	}
	return $hour;
}


function mystr($string,$search1,$search2) {

	$tempstr= ltrim(strstr($string,$search1),$search1);
	$i= stripos($tempstr,$search2);
	return substr($tempstr,0,$i);
}

function leftstr($search1,$string) {

	$tempstr=explode($search1,$string);
	return $tempstr[0];
}

function charCodeAt($str, $i){
	return ord(substr($str, $i, 1));
}
?>