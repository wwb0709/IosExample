//
//  ResultView.h
//  huoche
//
//  Created by kan xu on 11-1-8.
//  Copyright 2011 paduu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class netControl;
@interface ResultView : UIViewController <UITableViewDataSource, UITabBarDelegate> {
	
	NSDictionary *controller;
	NSArray *keys;
	bool	way;
	
	netControl *mynet;
	
	IBOutlet UITableView *ListTable;
	IBOutlet UIView *VResultView;
	IBOutlet UIView *HResultView;
	
	IBOutlet UIViewController *NextView;

}

@property (nonatomic, retain) NSDictionary *controller;
@property (nonatomic, retain) NSArray *keys;
@property (nonatomic, retain) IBOutlet UIViewController *NextView;

@end
