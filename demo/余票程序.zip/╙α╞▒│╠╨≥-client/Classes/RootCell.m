//
//  RootCell.m
//  huoche
//
//  Created by kan xu on 11-1-7.
//  Copyright 2011 paduu. All rights reserved.
//

#import "RootCell.h"


@implementation RootCell

@synthesize lieLab, traincodeLab, startLab, arriveLab, starttimeLab, arrivetimeLab, listtimeLab;
@synthesize yzuoLab, rzuoLab, ywoLab, rwoLab, tzuoLab, zuo1Lab, zuo2Lab, baoLab, nozuoLab, levelLab;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code.
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}


- (void)dealloc {
    [super dealloc];
}


@end
