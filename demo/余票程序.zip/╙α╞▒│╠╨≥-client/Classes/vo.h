//
//  vo.h
//  huoche
//
//  Created by kan xu on 11-1-8.
//  Copyright 2011 paduu. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface vo : NSObject {
	
	NSString *appaddr;	//地址
	NSDate *chedate;	//发车时间
	NSDate *_chedate;	//发车时间
	NSString *chedatestr;		//
	NSString *start;	//起始站
	NSString *arrive;	//目的站
	NSArray *chetypes;	//车列表
	NSMutableDictionary *selchetypes;	//选择车列表
	NSString *cheflag;	//车标记
	NSString *traincode;	//列车号
	
	///////////////////////////////
	
	NSString *uptime;	//更新时间
	NSString *lieci;	//列次
	NSArray *chelist;	//返回车列表
	NSMutableDictionary *Tchelist;	//显示用表
	NSDictionary *pricelist;	//价格列表
	NSDictionary *selche;	//选择的列车
	///////////////////////////////
	
	NSArray *TimeIndex;

	
}

@property (nonatomic, retain) NSString *appaddr;
@property (nonatomic, retain) NSDate *chedate;
@property (nonatomic, retain) NSDate *_chedate;
@property (nonatomic, retain) NSString *chedatestr;
@property (nonatomic, retain) NSString *start;
@property (nonatomic, retain) NSString *arrive;
@property (nonatomic, retain) NSArray *chetypes;
@property (nonatomic, retain) NSMutableDictionary *selchetypes;
@property (nonatomic, retain) NSString *cheflag;
@property (nonatomic, retain) NSString *traincode;

@property (nonatomic, retain) NSString *uptime;
@property (nonatomic, retain) NSString *lieci;
@property (nonatomic, retain) NSArray *chelist;
@property (nonatomic, retain) NSMutableDictionary *Tchelist;
@property (nonatomic, retain) NSDictionary *pricelist;
@property (nonatomic, retain) NSDictionary *selche;

@property (nonatomic, retain) NSArray *TimeIndex;




- (NSString *)Selche2Str;
- (NSString *)Selche2Flag;
- (void)chelist2T;

@end
