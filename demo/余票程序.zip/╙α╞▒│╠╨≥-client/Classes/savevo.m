//
//  savevo.m
//  huoche
//
//  Created by kan xu on 11-3-6.
//  Copyright 2011 paduu. All rights reserved.
//  这里不应该写在 model 里 而应该写成 静态调用

#import "savevo.h"


@implementation savevo

@synthesize cityarr;
@synthesize numdic;
@synthesize start,arrive,selchetypes;


- (id) init{
	
	if (self = [super init]) {
		[self loadcityarr];
		[self load];
	}
	return self;
}


- (void) savecityarr{

	[[NSUserDefaults standardUserDefaults] setObject:self.cityarr forKey:@"cityarr"];

}

- (void) loadcityarr{
	self.cityarr = [[NSUserDefaults standardUserDefaults] objectForKey:@"cityarr"];
	if (self.cityarr == nil){
		self.cityarr = [NSMutableArray arrayWithObjects:@"北京",@"上海",@"天津",@"郑州",@"南京",@"济南",@"武汉",@"徐州",@"蚌埠",@"湘潭",@"广州",@"合肥",nil];
	}
}

- (void) addcityarr:(NSString *)city{
	
	if ([self.cityarr containsObject:city]) {
		[self.cityarr removeObject:city];
	}
	else {
		[self.cityarr removeLastObject];
	}
	[self.cityarr insertObject:city atIndex:0];	 

}

- (void) save{
	
	[[NSUserDefaults standardUserDefaults] setObject:self.start forKey:@"start"];
	[[NSUserDefaults standardUserDefaults] setObject:self.arrive forKey:@"arrive"];
	[[NSUserDefaults standardUserDefaults] setObject:self.selchetypes forKey:@"selchetypes"];
	[[NSUserDefaults standardUserDefaults] setObject:self.cityarr forKey:@"cityarr"];

}

- (void) load{

	self.start = [[NSUserDefaults standardUserDefaults] objectForKey:@"start"];
	self.arrive = [[NSUserDefaults standardUserDefaults] objectForKey:@"arrive"];
	//self.selchetypes = [[NSUserDefaults standardUserDefaults] objectForKey:@"selchetypes"];
	//初始化的地方直接使用了
	if (self.start == nil)
		self.start = @"";
	if (self.arrive == nil)
		self.arrive = @"";	
}

@end
