//
//  TrainTypeTable.h
//  huoche
//
//  Created by kan xu on 11-1-7.
//  Copyright 2011 paduu. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TrainTypeTable : UIViewController <UITableViewDataSource, UITabBarDelegate> {
	
	NSArray *controller;
	NSMutableDictionary *selectcell;
	
	IBOutlet UISwitch *AllSel;
	IBOutlet UITableView *CheTable;
}

@property (nonatomic, retain) NSArray *controller;

- (IBAction)SelAll:(id)sender;

@end
