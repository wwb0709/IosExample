//
//  savevo.h
//  huoche
//
//  Created by kan xu on 11-3-6.
//  Copyright 2011 paduu. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface savevo : NSObject {
	
	NSMutableArray *cityarr;	//城市列表
	NSMutableDictionary *numdic;	 //没用到
	NSString *start;	 //用户上次出发站点
	NSString *arrive;	//用户上次抵达站点
	NSMutableDictionary *selchetypes;	//用户上次选择的车型
}

@property (nonatomic, retain) NSMutableArray *cityarr;
@property (nonatomic, retain) NSMutableDictionary *numdic;

@property (nonatomic, retain) NSString *start;
@property (nonatomic, retain) NSString *arrive;
@property (nonatomic, retain) NSMutableDictionary *selchetypes;


- (void)savecityarr;
- (void)loadcityarr;
- (void)addcityarr:(NSString *)city;

- (void)save;
- (void)load;

@end
