//
//  model.m
//  huoche
//
//  Created by kan xu on 11-1-8.
//  Copyright 2011 paduu. All rights reserved.
//  model 做为重要的数据源，负责管理数据和分配消息，本程序十分小,所以只有一个model
//  mvc模式下，一般model做为单例出现，保证数据的唯一性。可以直接看看

#import "model.h"

@implementation model

@synthesize Modelvo;
@synthesize Modelsave;
@synthesize NetMsgErr;
@synthesize NetMsgche;
@synthesize NetMsgprice;


+ (model *)getInstance {
	
	static model *_instance = nil;
	
	@synchronized(self){
		if (!_instance){
			_instance = [[model alloc] init];
			[_instance initModel];
		}
	}
	
	return _instance;
}


- (void)initModel{
	//初始化各个vo
	self.Modelvo = [[vo alloc] init];
	self.Modelsave = [[savevo alloc] init];
	//网络标记符
	NetMsgErr = @"NetErr";
	NetMsgche = @"cheOK";
	NetMsgprice = @"priceOK";

}


@end
