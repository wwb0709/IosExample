//
//  KYViewController.m
//  STRShare
//
//  Created by chen xin on 12-9-18.
//  Copyright (c) 2012年 Kingyee. All rights reserved.
//

#import "KYViewController.h"

@interface KYViewController ()

@end

@implementation KYViewController

@synthesize shareVC;

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"STRShare";
	// Do any additional setup after loading the view, typically from a nib.
    
    shareVC = [[KYShareViewController alloc] init];
    shareVC.title = @"分享";
    shareVC.shareText = @"今儿个真高兴！";
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)shareBtnClicked:(id)sender {
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"分享到" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"新浪微博", @"腾讯微博", @"人人网", nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackTranslucent;
    [actionSheet showInView:[UIApplication sharedApplication].keyWindow];
    [actionSheet release];
}

#pragma mark - uiactionsheet delegate 
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        shareVC.shareType = SinaWeibo;
        [self.navigationController pushViewController:shareVC animated:YES];
    }
    else if (buttonIndex == 1) {
        shareVC.shareType = Tencent;
        [self.navigationController pushViewController:shareVC animated:YES];
    }
    else if (buttonIndex == 2) {
        shareVC.shareType = RenrenShare;
        [self.navigationController pushViewController:shareVC animated:YES];
    }
}

@end
