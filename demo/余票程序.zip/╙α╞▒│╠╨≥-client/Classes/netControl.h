//
//  netControl.h
//  huoche
//
//  Created by kan xu on 11-1-9.
//  Copyright 2011 paduu. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface netControl : NSObject {
	
	NSMutableData *receivedData;
	MBProgressHUD *HUD;

}

- (BOOL)TestNet;
- (void)GetCheList;
- (void)GetChePrice;

@end
