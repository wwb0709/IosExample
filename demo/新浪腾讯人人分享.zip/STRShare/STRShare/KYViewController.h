//
//  KYViewController.h
//  STRShare
//
//  Created by chen xin on 12-9-18.
//  Copyright (c) 2012年 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KYShareViewController.h"

@interface KYViewController : UIViewController <UIActionSheetDelegate>

@property (nonatomic, retain)KYShareViewController *shareVC;

- (IBAction)shareBtnClicked:(id)sender;

@end
