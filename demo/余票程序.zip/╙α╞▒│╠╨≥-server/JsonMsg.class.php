<?php

/*************************************************

jsonmsg - the PHP msg client

*************************************************/

class JsonMsg
{
	/**** Public variables ****/

	/* user definable vars */

	var $result=NULL;
	var $error=NULL;

/*======================================================================*\
	Function:	jsonout
	Purpose:
	Input:
	Output:
\*======================================================================*/

	function jsonout(){
		$outmsg["error"] =$this->error;
		$outmsg["result"] =$this->result;
		echo preg_replace("#\\\u([0-9a-f]+)#ie", "iconv('UCS-2', 'UTF-8', pack('H4', '\\1'))", json_encode($outmsg));
	}
}

?>
