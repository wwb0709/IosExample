//
//  ZJTGloble.h
//  zjtSinaWeiboClient
//
//  Created by Jianting Zhu on 12-5-8.
//  Copyright (c) 2012年 ZUST. All rights reserved.
//

#define DID_GET_TOKEN_IN_WEB_VIEW @"didGetTokenInWebView"
