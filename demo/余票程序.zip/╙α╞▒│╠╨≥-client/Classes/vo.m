//
//  vo.m
//  huoche
//
//  Created by kan xu on 11-1-8.
//  Copyright 2011 paduu. All rights reserved.
//

#import "vo.h"
#import "tooles.h"

@implementation vo

@synthesize appaddr;
@synthesize chedate;
@synthesize _chedate;
@synthesize chedatestr;
@synthesize start;
@synthesize arrive;
@synthesize chetypes;
@synthesize selchetypes;
@synthesize cheflag;
@synthesize traincode;

@synthesize uptime;
@synthesize lieci;
@synthesize chelist;
@synthesize Tchelist;
@synthesize pricelist;
@synthesize selche;

@synthesize TimeIndex;
//初始化定义
- (id) init{

	if (self = [super init]) {
		self.appaddr = @"http://127.0.0.1/app/index.php";
		
		self.chedate = [NSDate date];
		
		self.chetypes = [NSArray arrayWithObjects:@"动车",@"直特",@"特快",@"快速",@"普快",@"普客",@"临客",nil];		
		self.TimeIndex = [@"0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23" componentsSeparatedByString:@","];
		self.Tchelist = [NSMutableDictionary dictionary];
		self.selchetypes = [[NSUserDefaults standardUserDefaults] objectForKey:@"selchetypes"];
		if (self.selchetypes == nil)
			self.selchetypes = [NSMutableDictionary dictionaryWithObjectsAndKeys:
								@"1",@"动车",@"1",@"直特",@"1",@"特快",@"0",@"快速",@"0",@"普快",@"0",@"普客",@"0",@"临客",nil];
	
	}
	return self;
}

- (void) setChedate:(NSDate *)indate{
	
	chedate = indate;
	self.chedatestr = [tooles Date2Str:indate];
	self._chedate = indate;
}

- (NSDate *) chedate{
	
	return self._chedate;

}


//将获得的array 转换 为需要的含有index的 NSMutableDictionary 形式供检索
- (void) chelist2T{
	
	
	[Tchelist removeAllObjects];
	//for (NSString *indexstr in TimeIndex) [Tchelist setObject:NULL forKey:indexstr];
	
	for (id key in TimeIndex){
		[Tchelist setObject:[NSNull null] forKey:key];
	}
	
	
	for (id key in chelist){
		
		
		NSString *tempstr = [key objectForKey:@"startt"];
		
		NSMutableArray *array =[[NSMutableArray alloc] init];
		
		if ([Tchelist objectForKey:tempstr] != [NSNull null]) {
			if ([[Tchelist objectForKey:tempstr] isKindOfClass:[NSArray class]]) {
				[[Tchelist objectForKey:tempstr] addObject:key];
			}
			else {
				[array addObject:[Tchelist objectForKey:tempstr]];
				[array addObject:key];
				[Tchelist setObject:array forKey:tempstr];
			}
		}
		else {
			//[Tchelist setObject:key forKey:tempstr];
			[array addObject:key];
			[Tchelist setObject:array forKey:tempstr];
		}
		
		[array release];
		
	} 
}


- (NSString *) Selche2Str{
	
	NSString *tmpstr = @"车型:";
	
	if ([[self Selche2Flag] isEqualToString:@"1111111"]) {
		return @"车型:全部";
	}
	
	for (id key in [selchetypes allKeys]){
		if ([[selchetypes objectForKey:key] isEqualToString:@"1"]) {
			tmpstr = [[tmpstr stringByAppendingString:@" "] stringByAppendingString:[key description]];
		}
	}
	
	return tmpstr;
	
}

- (NSString *) Selche2Flag{
	
	long tmpflag = 0;
	

	for (id key in [selchetypes allKeys]){
		
		if ([key isEqualToString:@"动车"]) {
			if ([[selchetypes objectForKey:key] isEqualToString:@"1"]) tmpflag = tmpflag + 1000000;
		}
		
		if ([key isEqualToString:@"直特"]) {
			if ([[selchetypes objectForKey:key] isEqualToString:@"1"]) tmpflag = tmpflag + 100000;
		}
		
		if ([key isEqualToString:@"特快"]) {
			if ([[selchetypes objectForKey:key] isEqualToString:@"1"]) tmpflag = tmpflag + 10000;
		}
		
		if ([key isEqualToString:@"快速"]) {
			if ([[selchetypes objectForKey:key] isEqualToString:@"1"]) tmpflag = tmpflag + 1000;
		}
		
		if ([key isEqualToString:@"普快"]) {
			if ([[selchetypes objectForKey:key] isEqualToString:@"1"]) tmpflag = tmpflag + 100;
		}
			
		if ([key isEqualToString:@"普客"]) {
			if ([[selchetypes objectForKey:key] isEqualToString:@"1"]) tmpflag = tmpflag + 10;
		}
		
		if ([key isEqualToString:@"临客"]) {
			if ([[selchetypes objectForKey:key] isEqualToString:@"1"]) tmpflag = tmpflag + 1;
		}
		
	}
	
	self.cheflag = [NSString stringWithFormat:@"%d",tmpflag];
	
	return [NSString stringWithFormat:@"%d",tmpflag];
	

}




@end
